#!/bin/bash
new_account_profile=$1
policyarn=$2
aws iam list-entities-for-policy --profile $new_account_profile --policy-arn $policyarn
if [ $? -eq 0 ]; then
        echo true > policyexists
else
        echo false > policyexists
fi
