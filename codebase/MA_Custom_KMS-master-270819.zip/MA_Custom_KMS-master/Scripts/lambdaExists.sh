#!/bin/bash
new_account_profile=$1
fn_name=$2
aws lambda get-function --function-name ${fn_name} --profile ${new_account_profile}
if [ $? -eq 0 ]; then
        echo true > lambdaexists
else
        echo false > lambdaexists
fi
