
#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
# This script needs improvement. This code should be moved to pipiline code. Also the directory structure needs to be modified.
set -e
kmsstackname=${1}
profile=${2}
region=${3}
lambdaName=${4}
lambdaRoleName=${5}
lambdaPOLName=${6}
business_unit=${7}
major_function=${8}
service=${9}
cost_center=${10}
environment=${11}
service_level=${12}
work_order=${13}
creator=${14}
kmsname=${15}

aws cloudformation create-stack  \
		   --stack-name $kmsstackname \
				   --template-body file://template/CustomKMS_v0.1.yml \
				   --capabilities CAPABILITY_NAMED_IAM \
				   --parameters \
ParameterKey=KMSName,ParameterValue="$kmsname" \
ParameterKey=region,ParameterValue="$region" \
ParameterKey=LambdaName,ParameterValue="$lambdaName" \
ParameterKey=LambdaRoleName,ParameterValue="$lambdaRoleName" \
ParameterKey=LambdaPOLName,ParameterValue="$lambdaPOLName" \
--tags Key="Business Unit",Value=$business_unit \
	   Key="Major Function",Value=$major_function \
	   Key=Service,Value=$service \
	   Key="Cost Centre",Value=$cost_center \
	   Key=Environment,Value=$environment \
	   Key="Service Level",Value=$service_level \
	   Key="Work Order",Value=$work_order \
	   Key=Creator,Value=$creator \
--profile $profile
aws cloudformation wait stack-create-complete --stack-name $kmsstackname --profile $profile
