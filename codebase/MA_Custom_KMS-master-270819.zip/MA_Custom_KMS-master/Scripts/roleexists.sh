#!/bin/bash
rolearn=$1
filename=$2
grep $rolearn $filename
if [ $? -eq 0 ]; then
        echo true > roleexists
else
        echo false > roleexists
fi
