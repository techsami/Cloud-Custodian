#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
set -e
role_stack_name=${1}
region=${2}
environment_classification=${3}
creator_val=${4}
business_unit=${5}
major_function=${6}
service=${7}
work_order=${8}
cost_center=${9}
service_level=${10}
environment=${11}
profile=${12}
templatefile_path="file://./adfsroles/MultiAccount_IAM_Standard_Roles_v0.4.yml"
aws cloudformation create-stack  \
			   --stack-name $role_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=Region,ParameterValue="$region" \
	ParameterKey=Environment,ParameterValue="$environment_classification" \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
#aws cloudformation wait stack-create-complete --stack-name $role_stack_name --profile $profile
 
