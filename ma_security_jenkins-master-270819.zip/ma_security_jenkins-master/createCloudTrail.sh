#!/bin/bash -xe
#source ~/.bash_profile
logbucket_name=$1
profile=$2
business_unit=$3
major_function=$4
service=$5
work_order=$6
cost_center=$7
service_level=$8
environment=$9
creator_val=$10
cloudtrail_stackname=$11
aws cloudformation create-stack  \
		   --stack-name $cloudtrail_stackname \
                   --template-body file://./cloudtrail.yml \
                   --capabilities CAPABILITY_NAMED_IAM \
                   --parameters \
ParameterKey=AccessControl,ParameterValue=LogDeliveryWrite \
ParameterKey=BucketName,ParameterValue=$logbucket_name \
ParameterKey=BusinessUnit,ParameterValue=$business_unit \
ParameterKey=MajorFunction,ParameterValue=$major_function \
ParameterKey=Service,ParameterValue=$service \
ParameterKey=WorkOrder,ParameterValue=$work_order \
ParameterKey=CostCentre,ParameterValue=$cost_center \
--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
--profile $profile
