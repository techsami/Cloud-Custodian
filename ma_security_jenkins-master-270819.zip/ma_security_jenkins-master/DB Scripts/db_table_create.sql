#This script will create tables in the DB.

create table org_root_mail (account_mail VARCHAR(100) , used boolean ,PRIMARY KEY ( account_mail ));
Create table org_cidr_range (cidr_block VARCHAR(50),tshirt_size varchar(2),region varchar(10),used boolean, primary key(cidr_block));
Create table org_accounts (account_number integer,account_name varchar(50),account_email nvarchar(50),cost_center nvarchar(50),work_order nvarchar(50),requestor nvarchar(50),owner nvarchar(50),primary key(account_number));
