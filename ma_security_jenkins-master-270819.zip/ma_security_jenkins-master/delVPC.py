#!/usr/bin/env python

import boto3
import sys

session = boto3.session.Session(profile_name=sys.argv[1])
client = session.client('ec2')
regions = client.describe_regions()

for regionName in regions['Regions']:
	region = regionName['RegionName']
	client = session.client('ec2',region_name=region)
	
	print '**************************\nRegion:', region
	
	response = client.describe_internet_gateways()
	try:
		try:
			igw = response['InternetGateways'][0]['InternetGatewayId']
			print '\nInternet Gateway Found. Id:',igw
		except:
			print 'No IGW'	
		
		try:
			print 'trying detaching..'
			vpc = response['InternetGateways'][0]['Attachments'][0]['VpcId']
			response = client.detach_internet_gateway(
				DryRun=False,
				InternetGatewayId=igw,
				VpcId=vpc
			)
		
			print 'Successfully detached IGW from the VPC'
			
		except:
			print 'No attachment found with the IGW'
			
		finally:
			delIGW = client.delete_internet_gateway(
				DryRun=False,
				InternetGatewayId=igw
			)
	
			print 'Successfully deleted IGW from',region
	except:
		print 'No IGW found in: ',region
		
	response = client.describe_subnets()
	print '\nSubnets found :',len(response['Subnets'])
	
	for subnets in response['Subnets']:
		subnet = subnets['SubnetId']
		print 'Subnet Id:', subnet
		
		delSubnet = client.delete_subnet(
			SubnetId=str(subnet),
			DryRun=False
		)
		
		print 'Subnet deleted successfully'
			
	
	response = client.describe_vpcs()
	try:
		VPC = response['Vpcs'][0]['VpcId']
		print '\nVPC Id:',VPC
			
		response = client.delete_vpc(
			VpcId=str(VPC),
			DryRun=False
		)
		print 'VPC deleted successfully'
	except:
		print '\nNo VPC found'
		
	response1 = client.describe_dhcp_options()
	try:
		dhcp = response1['DhcpOptions'][0]['DhcpOptionsId']
		print '\nDHCP Options Id:',dhcp
		
		response = client.delete_dhcp_options(
			DhcpOptionsId=str(dhcp),
			DryRun=False
		)
		
		print 'DHCP options deleted successfully'
	except:
		print '\nNo DHCP options found'
						
print '**************************\n\nAll default resources deleted successfully\n\n**************************'
