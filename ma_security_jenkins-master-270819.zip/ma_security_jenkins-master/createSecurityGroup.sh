#!/bin/bash -xe
#source ~/.bash_profile

aws cloudformation create-stack --region eu-west-1  \
		   --stack-name securitygrpstack \
                   --template-body file://./securitygrp.yml \
                   --capabilities CAPABILITY_NAMED_IAM \
                   --parameters \
ParameterKey=BusinessUnit,ParameterValue=Enterprise \
ParameterKey=CidrIp1,ParameterValue=10.0.0.0/8 \
ParameterKey=CidrIp2,ParameterValue=10.0.0.0/8 \
ParameterKey=CidrIp3,ParameterValue=10.0.0.0/8 \
ParameterKey=CidrIp4,ParameterValue=10.0.0.0/8 \
ParameterKey=CidrIp5,ParameterValue=10.0.0.0/8 \
ParameterKey=CidrIp6,ParameterValue=10.0.0.0/8 \
ParameterKey=CostCentre,ParameterValue=TAFA \
ParameterKey=Description1,ParameterValue=test \
ParameterKey=Description2,ParameterValue=test \
ParameterKey=Description3,ParameterValue=test \
ParameterKey=Description4,ParameterValue=test \
ParameterKey=Description5,ParameterValue=test \
ParameterKey=Description6,ParameterValue=test \
ParameterKey=Environment,ParameterValue=Development \
ParameterKey=FromPort1,ParameterValue=80 \
ParameterKey=FromPort2,ParameterValue=443 \
ParameterKey=FromPort3,ParameterValue=22 \
ParameterKey=FromPort4,ParameterValue=23 \
ParameterKey=FromPort5,ParameterValue=80 \
ParameterKey=FromPort6,ParameterValue=443 \
ParameterKey=InboundCount,ParameterValue=4 \
ParameterKey=IpProtocol1,ParameterValue=TCP \
ParameterKey=IpProtocol2,ParameterValue=TCP \
ParameterKey=IpProtocol3,ParameterValue=TCP \
ParameterKey=IpProtocol4,ParameterValue=TCP \
ParameterKey=IpProtocol5,ParameterValue=TCP \
ParameterKey=IpProtocol6,ParameterValue=TCP \
ParameterKey=MajorFunction,ParameterValue=Communications \
ParameterKey=OutboundCount,ParameterValue=2 \
ParameterKey=ServiceLevel,ParameterValue=Gold \
ParameterKey=SGDescription,ParameterValue=SG-TESTDEVAWSTEST \
ParameterKey=SGName,ParameterValue=SG-TESTDEVAWSTEST-002 \
ParameterKey=ToPort1,ParameterValue=80 \
ParameterKey=ToPort2,ParameterValue=443 \
ParameterKey=ToPort3,ParameterValue=22 \
ParameterKey=ToPort4,ParameterValue=23 \
ParameterKey=ToPort5,ParameterValue=80 \
ParameterKey=ToPort6,ParameterValue=443 \
ParameterKey=VPC,ParameterValue=$1 \
ParameterKey=WorkOrder,ParameterValue=6C040425 \
ParameterKey=Service,ParameterValue=DEMO \
--tags Key="Business Unit",Value=Enterprise \
       Key="Major Function",Value=Communications \
       Key=Service,Value=DEMO \
       Key="Cost Centre",Value=6hpc110010001288 \
       Key=Environment,Value=SandPit \
       Key="Service Level",Value=Gold \
       Key=WorkOrder,Value=6hpc110010001288 \
       Key=Creator,Value=avinash.gupta@edfenergy.com
--profile security
