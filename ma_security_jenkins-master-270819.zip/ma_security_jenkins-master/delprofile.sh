#!/bin/bash

profile=$1

l=`wc -l < vineet.txt`
sl=$((`wc -l < vineet.txt` - 3))
line=`head -n "$sl" vineet.txt | tail -n1`

if [ "$line" = "$profile" ]
then
    sed -i ""$sl","$l"d" vineet.txt
    sed -i '$ d' vineet.txt
    echo "Profile deleted successfully!"
else
    echo "Profile not found!"
fi
