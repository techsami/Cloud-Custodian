#!/bin/bash -xe
#source ~/.bash_profile
stack_name=$1
project_kms_name=$2
account_id=$3
environment=$4
business_unit=$5
major_function=$6
service=$7
work_order=$8
cost_center=$9
service_level=$10
description=$11

aws cloudformation create-stack  \
		   --stack-name $stack_name \
                   --template-body file://./kms.yml \
                   --parameters \
ParameterKey=AccountId,ParameterValue=$account_id \
ParameterKey=Description,ParameterValue=$11 \
ParameterKey=ProjectKMSName,ParameterValue=$project_kms_name \
ParameterKey=BusinessUnit,ParameterValue=$business_unit \
ParameterKey=MajorFunction,ParameterValue=$major_function \
ParameterKey=Service,ParameterValue=$service \
ParameterKey=CostCentre,ParameterValue=$cost_center \
ParameterKey=Environment,ParameterValue=$environment \
ParameterKey=ServiceLevel,ParameterValue=$service_level \
ParameterKey=WorkOrder,ParameterValue=$work_order \
--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key=WorkOrder,Value=$work_order \
       Key=Creator,Value=sourav.biswas@edfenergy.com \
