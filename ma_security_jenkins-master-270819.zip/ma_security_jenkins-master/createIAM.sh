#!/bin/bash -xe
#source ~/.bash_profile
stack_name=$1
profile=$2
dailyBackUpLambda_name=$3
monthlyBackUpLambda_name=$4
yearlyBackUpLambda_name=$5
lambdaExecutionRole_name=$6
adminRole_name=$7
business_unit=$8
major_function=$9
service=${10}
work_order=${11}
cost_center=${12}
service_level=${13}
environment=${14}
creator=${15}

aws cloudformation create-stack  \
		   --stack-name $stack_name \
                   --template-body file://./iam.yml \
                   --capabilities CAPABILITY_NAMED_IAM \
                   --parameters \
ParameterKey=DailyBackUpLambdaName,ParameterValue="$dailyBackUpLambda_name" \
ParameterKey=MonthlyBackUpLambdaName,ParameterValue="$monthlyBackUpLambda_name" \
ParameterKey=YearlyBackUpLambdaName,ParameterValue="$yearlyBackUpLambda_name" \
ParameterKey=LambdaRoleName,ParameterValue="$lambdaExecutionRole_name" \
ParameterKey=AdminRoleName,ParameterValue="$adminRole_name" \
--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator \
--profile $profile
