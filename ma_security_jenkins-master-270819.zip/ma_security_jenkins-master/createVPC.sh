#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
set -e
vpc_template=${1}
vpc_stack_name=${2}
cidr_val=${3}
creator_val=${4}
profile=${5}
business_unit=${6}
major_function=${7}
service=${8}
work_order=${9}
cost_center=${10}
service_level=${11}
environment=${12}
vpc_name=${13}
dhcpoption_name=${14}
#Assigning variables that are coming from Pipeline based on specific VPC template starts here
####VPC with 1 private subnet####
if [ $vpc_template == "VPC_template_01" ]
then
	privatesubnetname_a=${15}
	private_roottable_name_a=${16}
	PrivateBlock1=${17}
	loggroup_name=${18}
	logstream_name=${19}
	vpcflowlog_role_name=${20}
	region=${21}
	environment=${22}
	templatefile_path="file://./vpc.yml"
	#Run create stack for creating VPC
	aws cloudformation create-stack  \
			   --stack-name $vpc_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=Environment,ParameterValue="$environment" \
	ParameterKey=VPCFlowLogRoleARN,ParameterValue="$vpcflowlog_role_name" \
	ParameterKey=PrivateBlock4,ParameterValue="" \
	ParameterKey=PrivateBlock3,ParameterValue="" \
	ParameterKey=LogGroupName,ParameterValue="$loggroup_name" \
	ParameterKey=LogStreamName,ParameterValue="$logstream_name" \
	ParameterKey=InternetGatewayName,ParameterValue="" \
	ParameterKey=PrivateSubnet1Name,ParameterValue=$privatesubnetname_a \
	ParameterKey=PrivateSubnet2Name,ParameterValue="" \
	ParameterKey=PrivateSubnet3Name,ParameterValue="" \
	ParameterKey=PrivateSubnet4Name,ParameterValue="" \
	ParameterKey=PublicSubnet1Name,ParameterValue="" \
	ParameterKey=PublicSubnet2Name,ParameterValue="" \
	ParameterKey=PrivateSubnet1RouteTableName,ParameterValue=$private_roottable_name_a \
	ParameterKey=PrivateSubnet2RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet3RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet4RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet1RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet2RouteTableName,ParameterValue="" \
	ParameterKey=PSub1SecurityGroupName,ParameterValue="" \
	ParameterKey=PSub2SecurityGroupName,ParameterValue="" \
	ParameterKey=ILBTargetName,ParameterValue="" \
	ParameterKey=INTALBName,ParameterValue=""\
	ParameterKey=VPCName,ParameterValue=$vpc_name \
	ParameterKey=DHCPOptionsName,ParameterValue=$dhcpoption_name \
	ParameterKey=PublicSubnetCount,ParameterValue=0 \
	ParameterKey=PrivateSubnetCount,ParameterValue=1 \
	ParameterKey=PublicBlock2,ParameterValue="" \
	ParameterKey=PrivateBlock1,ParameterValue=$PrivateBlock1 \
	ParameterKey=PrivateBlock2,ParameterValue="" \
	ParameterKey=PublicBlock1,ParameterValue="" \
	ParameterKey=VPCCIDR,ParameterValue=$cidr_val \
	ParameterKey=Region,ParameterValue=$region \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
fi
####VPC with 2 private subnet####
if  [ $vpc_template == "VPC_template_02" ]
then
	privatesubnetname_a=${15}
        privatesubnetname_b=${16}
	PrivateBlock1=${17}
	PrivateBlock2=${18}
	private_roottable_name_a=${19}
	private_roottable_name_b=${20}
	loggroup_name=${21}
	logstream_name=${22}
	vpcflowlog_role_name=${23}
	region=${24}
	environment=${25}
	templatefile_path="file://./vpc.yml"
	aws cloudformation create-stack  \
			   --stack-name $vpc_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
        ParameterKey=Environment,ParameterValue="$environment" \
	ParameterKey=VPCFlowLogRoleARN,ParameterValue="$vpcflowlog_role_name" \
	ParameterKey=PrivateBlock4,ParameterValue="" \
	ParameterKey=PrivateBlock3,ParameterValue="" \
	ParameterKey=LogGroupName,ParameterValue="$loggroup_name" \
	ParameterKey=LogStreamName,ParameterValue="$logstream_name" \
	ParameterKey=InternetGatewayName,ParameterValue="" \
	ParameterKey=PrivateSubnet1Name,ParameterValue=$privatesubnetname_a \
	ParameterKey=PrivateSubnet2Name,ParameterValue=$privatesubnetname_b \
	ParameterKey=PrivateSubnet3Name,ParameterValue="" \
	ParameterKey=PrivateSubnet4Name,ParameterValue="" \
	ParameterKey=PublicSubnet1Name,ParameterValue="" \
	ParameterKey=PublicSubnet2Name,ParameterValue="" \
	ParameterKey=PrivateSubnet1RouteTableName,ParameterValue=$private_roottable_name_a \
	ParameterKey=PrivateSubnet2RouteTableName,ParameterValue=$private_roottable_name_b \
	ParameterKey=PrivateSubnet3RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet4RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet1RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet2RouteTableName,ParameterValue="" \
	ParameterKey=PSub1SecurityGroupName,ParameterValue="" \
	ParameterKey=PSub2SecurityGroupName,ParameterValue="" \
	ParameterKey=ILBTargetName,ParameterValue="" \
	ParameterKey=INTALBName,ParameterValue=""\
	ParameterKey=VPCName,ParameterValue=$vpc_name \
	ParameterKey=DHCPOptionsName,ParameterValue=$dhcpoption_name \
	ParameterKey=PublicSubnetCount,ParameterValue=0 \
	ParameterKey=PrivateSubnetCount,ParameterValue=2 \
	ParameterKey=PublicBlock2,ParameterValue="" \
	ParameterKey=PrivateBlock1,ParameterValue=$PrivateBlock1 \
	ParameterKey=PrivateBlock2,ParameterValue=$PrivateBlock2 \
	ParameterKey=PublicBlock1,ParameterValue="" \
	ParameterKey=VPCCIDR,ParameterValue=$cidr_val \
	ParameterKey=Region,ParameterValue=$region \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
fi
####VPC with 4 private and 2 public subnet####
if  [ $vpc_template == "VPC_template_04" ]
then
	privatesubnetname_a=${15}
    privatesubnetname_b=${16}
	PrivateBlock1=${17}
	PrivateBlock2=${18}
	private_roottable_name_a=${19}
	private_roottable_name_b=${20}
	privatesubnetname_2a=${21}
    privatesubnetname_2b=${22}
	PrivateBlock3=${23}
	PrivateBlock4=${24}
	private_roottable_name_2a=${25}
	private_roottable_name_2b=${26}
	loggroup_name=${27}
	logstream_name=${28}
	vpcflowlog_role_name=${29}
	region=${30}
	environment=${31}
	templatefile_path="file://./vpc.yml"
	parameterfile_path="file://./cfntemplate_parameters/vpc_template_04.json"
	aws cloudformation create-stack  \
			   --stack-name $vpc_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=Environment,ParameterValue="$environment" \
	ParameterKey=VPCFlowLogRoleARN,ParameterValue="$vpcflowlog_role_name" \
	ParameterKey=PrivateBlock4,ParameterValue=$PrivateBlock4 \
	ParameterKey=PrivateBlock3,ParameterValue=$PrivateBlock3 \
	ParameterKey=LogGroupName,ParameterValue="$loggroup_name" \
	ParameterKey=LogStreamName,ParameterValue="$logstream_name" \
	ParameterKey=InternetGatewayName,ParameterValue="" \
	ParameterKey=PrivateSubnet1Name,ParameterValue=$privatesubnetname_a \
	ParameterKey=PrivateSubnet2Name,ParameterValue=$privatesubnetname_b \
	ParameterKey=PrivateSubnet3Name,ParameterValue=$privatesubnetname_2a \
	ParameterKey=PrivateSubnet4Name,ParameterValue=$privatesubnetname_2b \
	ParameterKey=PublicSubnet1Name,ParameterValue="" \
	ParameterKey=PublicSubnet2Name,ParameterValue="" \
	ParameterKey=PrivateSubnet1RouteTableName,ParameterValue=$private_roottable_name_a \
	ParameterKey=PrivateSubnet2RouteTableName,ParameterValue=$private_roottable_name_b \
	ParameterKey=PrivateSubnet3RouteTableName,ParameterValue=$private_roottable_name_2a \
	ParameterKey=PrivateSubnet4RouteTableName,ParameterValue=$private_roottable_name_2b \
	ParameterKey=PublicSubnet1RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet2RouteTableName,ParameterValue="" \
	ParameterKey=PSub1SecurityGroupName,ParameterValue="" \
	ParameterKey=PSub2SecurityGroupName,ParameterValue="" \
	ParameterKey=ILBTargetName,ParameterValue="" \
	ParameterKey=INTALBName,ParameterValue=""\
	ParameterKey=VPCName,ParameterValue=$vpc_name \
	ParameterKey=DHCPOptionsName,ParameterValue=$dhcpoption_name \
	ParameterKey=PublicSubnetCount,ParameterValue=0 \
	ParameterKey=PrivateSubnetCount,ParameterValue=4 \
	ParameterKey=PublicBlock2,ParameterValue="" \
	ParameterKey=PrivateBlock1,ParameterValue=$PrivateBlock1 \
	ParameterKey=PrivateBlock2,ParameterValue=$PrivateBlock2 \
	ParameterKey=PublicBlock1,ParameterValue="" \
	ParameterKey=VPCCIDR,ParameterValue=$cidr_val \
	ParameterKey=Region,ParameterValue=$region \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
fi
####VPC with 2 public subnet/load balancer/security group####
if [ $vpc_template == "VPC_template_06" ]
then
    publicsubnetname_a=${15}
    publicsubnetname_b=${16}
	PublicBlock1=${17}
	PublicBlock2=${18}
	public_roottable_name=${19}
	PubSub1SecurityGroupName=${20}
	PubSub2SecurityGroupName=${21}
	loggroup_name=${22}
	logstream_name=${23}
	vpcflowlog_role_name=${24}
	internetgateway_name=${25}
	public_roottable_2_name=${26}
	region=${27}
	loadbalancerrequired=${28}
	ILbTargetName=${29}
	ILbName=${30}
	environment=${31}
	templatefile_path="file://./vpc.yml"
	aws cloudformation create-stack  \
			   --stack-name $vpc_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=Environment,ParameterValue="$environment" \
	ParameterKey=VPCFlowLogRoleARN,ParameterValue="$vpcflowlog_role_name" \
	ParameterKey=PrivateBlock4,ParameterValue="" \
	ParameterKey=PrivateBlock3,ParameterValue="" \
	ParameterKey=LogGroupName,ParameterValue="$loggroup_name" \
	ParameterKey=LogStreamName,ParameterValue="$logstream_name" \
	ParameterKey=InternetGatewayName,ParameterValue=$internetgateway_name \
	ParameterKey=PrivateSubnet1Name,ParameterValue="" \
	ParameterKey=PrivateSubnet2Name,ParameterValue="" \
	ParameterKey=PrivateSubnet3Name,ParameterValue="" \
	ParameterKey=PrivateSubnet4Name,ParameterValue="" \
	ParameterKey=PublicSubnet1Name,ParameterValue=$publicsubnetname_a \
	ParameterKey=PublicSubnet2Name,ParameterValue=$publicsubnetname_b \
	ParameterKey=PrivateSubnet1RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet2RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet3RouteTableName,ParameterValue="" \
	ParameterKey=PrivateSubnet4RouteTableName,ParameterValue="" \
	ParameterKey=PublicSubnet1RouteTableName,ParameterValue=$public_roottable_name \
	ParameterKey=PublicSubnet2RouteTableName,ParameterValue=$public_roottable_2_name \
	ParameterKey=PSub1SecurityGroupName,ParameterValue=$PubSub1SecurityGroupName \
	ParameterKey=PSub2SecurityGroupName,ParameterValue=$PubSub2SecurityGroupName \
	ParameterKey=ILBTargetName,ParameterValue=$ILbTargetName \
	ParameterKey=INTALBName,ParameterValue=$ILbName\
	ParameterKey=VPCName,ParameterValue=$vpc_name \
	ParameterKey=DHCPOptionsName,ParameterValue=$dhcpoption_name \
	ParameterKey=PublicSubnetCount,ParameterValue=2 \
	ParameterKey=PrivateSubnetCount,ParameterValue=0 \
	ParameterKey=PublicBlock2,ParameterValue=$PublicBlock2 \
	ParameterKey=PrivateBlock1,ParameterValue="" \
	ParameterKey=PrivateBlock2,ParameterValue="" \
	ParameterKey=PublicBlock1,ParameterValue=$PublicBlock1 \
	ParameterKey=VPCCIDR,ParameterValue=$cidr_val \
	ParameterKey=LoadBalancerRequired,ParameterValue=$loadbalancerrequired \
	ParameterKey=Region,ParameterValue=$region \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
fi
