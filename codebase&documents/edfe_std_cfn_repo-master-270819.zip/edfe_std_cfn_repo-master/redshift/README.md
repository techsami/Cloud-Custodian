# Cloudformation template for redshift


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for redshift
`BusinessUnit=Enterprise;ClusterType=multi-node;CostCentre=TABB;DatabaseName=redshiftzdb001;Environment=Development;KmsKeyId=arn:aws:kms:eu-west-1:592388890799:key/09cbf86c-963d-4d9d-991a-875e482d9ef2;MajorFunction=Communications;MasterUsername=defaultuser;MasterUserPassword=****;NodeType=ds2.xlarge;NumberOfNodes=5;PortNumber=5439;SecurityGroup=sg-6015cc06;Service=Boomi;ServiceLevel=Gold;Subnet=devtest-eu-west-1b-cdn;WorkOrder=6C040425`

##### Description for each Parameter 

* <b> DatabaseName </b>
: The name of the first database to be created when the cluster is created.

* <b>	ClusterType </b>
: The type of cluster

* <b>	NumberOfNodes </b>
: Value for single-node = 1 and for multi-node > 1

* <b>	SecurityGroup </b>
: Name of an existing SecurityGroup for the instance (Mandatory)

* <b> NodeType </b>
: The type of node to be provisioned

* <b>	KmsKeyId </b>
: ARN of KMS Key to encrypt the EBS volume. (Mandatory)

* <b>	MasterUsername </b>
: The user name that is associated with the master user account for the cluster that is being created

* <b>	MasterUserPassword </b>
: The password that is associated with the master user account for the cluster that is being created.

* <b>	PortNumber </b>
: The port number on which the cluster accepts incoming connections.

* <b>	RedshiftClusterSubnetGroup </b>
: Enter the name of the redshift cluster subnet group.

* <b>	Subnet </b>
: Instance subnet (Mandatory)

* <b>	Owner </b>
: Owner detals (Mandatory)

* <b>	BusinessUnit </b>
: List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)

* <b>	MajorFunction </b>
: Sub Business Unit or core component group (Mandatory)

* <b>	CostCentre </b>
: Cost Centre e.g. CITR, OXTR, TAG (Mandatory)

* <b> Environment </b>
:EDF Environments(SandPit\DEVTEST\Preproduction\Production)

* <b> ServiceLevel </b>
: EDF service levels  i.e Platinum\Gold\Silver\Bronze

* <b>	WorkOrder </b>
: Work Order Reference Number
