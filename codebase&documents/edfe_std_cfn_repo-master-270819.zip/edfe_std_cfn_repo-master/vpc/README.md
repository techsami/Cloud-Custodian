
# Cloudformation template for VPC


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for VPC
`BusinessUnit=Enterprise;CostCentre=TAFA;EIP=eipalloc-86222ebc;Environment=Development;MajorFunction=Communications;PrivateBlock1=20.0.3.0/24;PrivateBlock2=20.0.4.0/24;PrivateSubnetCount=1;PublicBlock1=20.0.1.0/24;PublicBlock2=20.0.2.0/24;PublicSubnetCount=1;Service=BOOMI;ServiceLevel=Gold;VPCCIDR=20.0.0.0/16;WorkOrder=1234`

###### Description for each Parameter

* <b>	EIP </b> : NAT Gateway 1 IP address

* <b>	PrivateSubnet1ACIDR </b> : Private subnet 1A CIDR in Availability Zone 1

* <b>	PrivateSubnet1AID </b> : Private subnet 1A ID in Availability Zone 1

* <b>	PrivateSubnet2ACIDR </b> : Private subnet 2A CIDR in Availability Zone 2

* <b>	PrivateSubnet2AID </b> : Private subnet 2A ID in Availability Zone 2

* <b>	PublicSubnet1CIDR </b> : Public subnet 1 CIDR in Availability Zone 1

* <b>	PublicSubnet1ID </b> : Public subnet 1 ID in Availability Zone 1

* <b>	PublicSubnet2CIDR </b> : Public subnet 2 CIDR in Availability Zone 2

* <b>	PublicSubnet2ID </b> : Public subnet 2 ID in Availability Zone 2

* <b>	VPCCIDR </b> : VPC CIDR

* <b>	VPCID </b> : VPC ID
*	<b> Owner </b>           : Owner detals (Mandatory)
*	<b> BusinessUnit </b>    : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)
*	<b> MajorFunction </b>   : Sub Business Unit or core component group (Mandatory)
*	<b> CostCentre </b>      : Cost Centre e.g. CITR, OXTR, TAG (Mandatory)
* <b> Environment </b>    : EDF Environments(SandPit\DEVTEST\Preproduction\Production)
*	<b> ServiceLevel </b>    : EDF service levels  i.e Platinum\Gold\Silver\Bronze
*	<b> WorkOrder  </b>      : Work Order Reference Number
