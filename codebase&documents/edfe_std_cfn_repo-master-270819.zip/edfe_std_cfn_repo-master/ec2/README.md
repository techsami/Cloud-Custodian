# Cloudformation template for EC2

##### Parameter needs to be passed.

You need to pass parameter in Jenkins,as mentioned in the below Sample.

###### Example for EC2
`InstanceType=t2.medium;Subnet=devtest-eu-west-1b-cdn;OS=RHEL-7.3;BackupStartTime=0300;BackupRetention=30;InstanceSchedule=24x7;EBSVolumeSize=50;EBSKMSKey=arn:aws:kms:eu-west-1:592388890799:key/09cbf86c-963d-4d9d-991a-875e482d9ef2;KeyName=AWS_PROD_BOOMI;IAMRole=Demo_Role;SecurityGroup=sg-0c15cc6a;Name=AWSZENKINSCFNTST001;BusinessUnit=Enterprise;MajorFunction=Communications;Service=LAN;CostCentre=CITR;Environment=Development;ServiceLevel=Gold;WorkOrder=1234`

###### Description for each Parameter :
* <b> InstanceType </b>     : EC2 instance type
* <b> Subnet </b>          : Instance subnet (Mandatory)
* <b> OS  </b>             : Instance  Operating system(LINUX\WINOWS)
*	<b> BackupStartTime </b>  : Time when EBS snapshots shall be generated. Preferably while the system is usually quiescent.
*	<b>BackupRetention </b> : Time till EBS snapshots shall be retained
*	<b> InstanceSchedule </b> : EC2 instance uptime (Mandatory). Please note, values other than 24x7 is applicable for Monday-Friday only
*	<b> EBSVolumeSize </b>    : Size of attached EBS volume in GB (Mandatory)
*	<b> EBSKMSKey </b>        : ARN of KMS Key to encrypt the EBS volume. (Mandatory)
*	<b> IAMRole </b>         : Provide role name to pass IAMRole to EC2 Instance Profile (Mandatory)
*	<b> KeyName </b>         : Name of an existing EC2 KeyPair to enable SSH access to the instances (Mandatory)
*	<b> SecurityGroup </b>    : Name of an existing SecurityGroup for the instance (Mandatory)
*	<b> Name  </b>           : The server hostname (Mandatory)
*	<b> Owner </b>           : Owner detals (Mandatory)
*	<b> BusinessUnit </b>    : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)
*	<b> MajorFunction </b>   : Sub Business Unit or core component group (Mandatory)
*	<b> CostCentre </b>      : Cost Centre e.g. CITR, OXTR, TAG (Mandatory)
* <b> Environment </b>    : EDF Environments(SandPit\DEVTEST\Preproduction\Production)
*	<b> ServiceLevel </b>    : EDF service levels  i.e Platinum\Gold\Silver\Bronze
*	<b> WorkOrder  </b>      : Work Order Reference Number



