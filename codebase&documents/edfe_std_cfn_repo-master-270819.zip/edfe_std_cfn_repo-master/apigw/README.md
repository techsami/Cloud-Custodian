# Cloudformation template for apigw


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for apigw
`Bucket=edfe-devservicecatalogcformtemplates;BurstLimits=200;Description=sampleDesc;DoesMethodRequireApiKey=false;FailOnWarnings=false;Key=Sample-Swagger_definition.json;NameUsagePlan=testUsage;QuotaLimits=5000;QuotaPeriod=MONTH;RateLimits=100;StageDescription=samplestage;StageName=Dev`


##### Description for each Parameter 

* <b>	Bucket </b>
: Name of the S3 bucket where swagger definition is kept.

* <b>	Key </b>
: Name of the Swagger Definition file to import.

* <b>	StageName </b>
: Name of the stage where API should be deployed.

* <b> StageDescription </b>
: Purpose of the deployment.

* <b> APIKeyName </b>
: 'Select Yes if you require API Key for Method(s) '.

* <b>	QuotaLimits </b>
: Number of api Calls (0-10000) that can be made over a period.

* <b>	QuotaPeriod </b>
: The time period for which the maximum limit of requests applies such as DAY, WEEK or MONTH.


* <b> BurstLimits </b>
: The burst limit for API Gateway.

* <b>	NameUsagePlan </b>
: Mention a name for Usage Plan.
