
### Objective 

The aim of this project is to provide a automation of AWS provisioning using Cloud Formation and service catalog. A CloudFormation  template  represent AWS resources like AMI, application stack  etc. which need to be created a particular serviceproject. Template is basically a text file in JSON/YML.  AWS  provide many built-in templates which can used for creating required resources. User can also  use a graphical tool provided by AWS ,  called template Designer in order to create custom templates. Make the templates more generic by appropriate use of controls at portfolio and product level. Enable integration with EDF Energy’s DevOps tools GitHub and Jenkins. 

<p align="center">
  <img src="https://git.aws.edfenergy.net/EDFTest/tsicfnrepo/blob/master/image/gitjenkins.JPG">
</p>

### Cloudformation

AWS CloudFormation gives developers and systems administrators an easy way to create and manage a collection of related AWS resources, provisioning and updating them in an orderly and predictable fashion.
Collection of AWS resources for provisioning, called templates. Templates define the AWS resources required for the product, the relationships between resources, and the parameters that the end user can plug in when they launch the product to configure security groups, create key pairs, and perform other customizations.

Following services we are going to use as a CFN templates.

- EC2
- S3
- CloudFront
- RDS
- Lambda
- API Gateway
- IAM
- SecurityGroups
- Boomi
- WAF 
- VPC & Subnet


### Purpose 

For deployment of AWS service in preprod and prod EDF decided to use tools like Jenkins, git, and AWS CloudFormation. Usually, the process is managed by two or more teams. One team is responsible for designing and developing an application, CloudFormation templates, and so on. The other team is generally responsible for deployment.
One of the challenges that maintaining CFN template for different way, for that CFN template prepare such way so same template can be use in service catalog as well as through Jenkins deployment also. 

We have prepare CFN template such way so same template can be use in service catalog as well as through Jenkins deployment also. 
There is a saperate user guide how to use service catalog but in this file we have describe how to use Jenkins for AWS service deployment using Jenkins. 


### Devops tool Solution

The solution will automatically deploy AWS resources using cloudformation through jenkins. Using this automation user can provisioned AWS services. Using DevOps tools and same CFN template (which was used in Service Catalog) user can provisioned in Pre-Prod & Prod environment. It is assumed that user should familiar DevOps tools (Git & Jenkins). And as prerequisites need to request for AWS access key & secret key.
For in details document, there is a EADME.md file which describe how to use Jenkins for AWS service deployment using Jenkins. 
Architectural features

* GitHub will be as source of cloudformation template 
	
	https://git.aws.edfenergy.net/EDFTest/tsicfnrepo

* Jenkins will utilize CloudFormation to deploy infrastructure.

	http://jenkins.aws.edfenergy.net:8080


#### Workflow

TSI team upload cloud formation template in GIT. Users need to find right AWS resource template/stack and version.

   https://git.aws.edfenergy.net/EDFTest/tsicfnrepo 

   For users/project these CFN templates are read only.
   There is a README.md file in each of the folder and user will get details versions and execution steps with parameters.

###### 1 	Project/users will create a Jenkins jobs by providing following details.

- Git URL and CFN template name & version
- AWS Access key & Secret Access Key
- Parameter (Sample parameter provided in each CFN template folder)

<p align="center">
  <img src="https://git.aws.edfenergy.net/EDFTest/tsicfnrepo/blob/master/image/jenkins-cfn1.jpg">
</p>

<p align="center">
  <img src="https://git.aws.edfenergy.net/EDFTest/tsicfnrepo/blob/master/image/jenkins-cfn2.jpg">
</p>

###### 2 	Now Project/users can execute a Jenkins Job to launch Environment.

###### 3 	If there is job failure due to CF/TF template, a email notification go to Admin/Project/Users.

###### 4 	After successful job execution environment will build in AWS. 

