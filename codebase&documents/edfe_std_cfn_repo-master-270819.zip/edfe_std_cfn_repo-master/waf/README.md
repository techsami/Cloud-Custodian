
# Cloudformation template for WAF


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for WAF
`CrossSiteScriptingProtectionParam=yes;IPSetWhitelist=20.0.0.0/24;SqlInjectionProtectionParam=yes`


###### Description for each Parameter

* <b> SqlInjectionProtectionParam </b> : Choose yes to enable the component designed to block common SQL injection      attacks.

* <b>	ActivateHttpFloodProtectionParam </b> : Choose yes to enable the component designed to block HTTP flood attacks.

* <b>	CrossSiteScriptingProtectionParam </b>: Choose yes to enable the component designed to block common XSS attacks.

* <b>	ActivateScansProbesProtectionParam </b> : Choose yes to enable the component designed to block scanners and probes.

* <b>	ActivateReputationListsProtectionParam </b> : Choose yes to block requests from IP addresses on third-party reputation lists (supported lists: spamhaus, torproject, and emergingthreats).

* <b>	ActivateBadBotProtectionParam </b> : Choose yes to enable the component designed to block bad bots and content      scrapers.

* <b>	AccessLogBucket </b> : Enter a name for the Amazon S3 bucket where you want to store Amazon
CloudFront access logs.

* <b>	SendAnonymousUsageData </b> : Send anonymous data to AWS to help us understand solution usage across our      customer base as a whole. To opt out of this feature, select No.

*  <b>	RequestThreshold </b> : If you chose yes for the Activate HTTP Flood Protection parameter, enter the maximum acceptable requests per FIVE-minute period per IP address. Minimum value of 2000. If you chose to deactivate this protection, ignore this parameter.

* <b>	ErrorThreshold </b> : If you chose yes for the Activate Scanners & Probes Protection parameter,     enter the maximum acceptable bad requests per minute per IP. If you chose to deactivate Scanners & Probes protection, ignore this parameter.

* <b>	WAFBlockPeriod </b> : If you chose yes for the Activate Scanners & Probes Protection parameters,      enter the period (in minutes) to block applicable IP addresses. If you chose to deactivate this protection, ignore this parameter.

* <b>	WAFRole </b> : Enter WAF Role ARN, Lambda functions will use the role to communicate with AWS services.

* <b>	WebACL </b> : Enter WEB ACL NAME.
