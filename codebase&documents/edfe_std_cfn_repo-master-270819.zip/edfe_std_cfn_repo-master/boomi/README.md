# BOOMI

Within the CIO Integration Technology Strategy Dell Boomi was selected as the strategic integration platform to support the digitisation of the Red network estate. The strategy recommends that as current integration technologies become end of life the functionality they support will be migrated to Dell Boomi.
Dell Boomi provides an iPaaS solution. This consists of a build and management user interface hosted in the Dell cloud and a runtime engine, which processes the business data, and which can be deployed in the Dell cloud (Atom Cloud), within an EDF Energy virtual private cloud such as Amazon Web Services (Molecule and Atom), and on premise (Molecule and Atom)
Having adopted two different deployment options, Boomi within the EDF Energy private cloud and Boomi within the EDF Energy owned datacentres, the platform enables integration through data transfers between applications both in the cloud and on premise as well as between both.
Following a successful proof of concept and non-production pilot for Dell Boomi in 2015, a Boomi molecule has now been setup within the EDF Energy AWS private cloud. Works have also started on the build of the on premise Molecule.
This design paper cover the details of the AWS Boomi Molecule.

<p align="center">
  <img src="https://git.aws.edfenergy.net/EDFTest/tsicfnrepo/blob/master/image/boomi.png">
</p>

Part of boomi cloudformation stack following AWS services going to launch

- EC2
- Cloudfront
- nternal loadbalancer 
- external loadbalancer
- EFS (Elastic File System)
- WAF
- RDS

<p align="center">
  <img src="https://git.aws.edfenergy.net/EDFTest/tsicfnrepo/blob/master/image/BoomiCFN.JPG">
</p>

##### Parameter need to pass

You need to pass parameter in jenkin, below sample given

###### Example for BOOMI
`AcmCertificateArn=arn:aws:acm:us-east-1:592388890799:certificate/52e44433-e261-40ac-8ac0-004d318041c4;Aliases=*.boomidt.edfenergy.com;Comments=cfront test;DBInstanceIdentifier=demoboomicfnstackdbjen;DBSubnetGroupName=dev2-rds-subnet-group;DomainName=origin.boomidt.edfenergy.com;ELBTargetName=ELBTargetName10;EXTALBName=EXTALBName10;ILBTargetName=ILBTargetName10;IncludeCookies=false;INTALBName=INTALBName10;KeyName=AWS_PROD_BOOMI;LBCertificateArn=arn:aws:acm:eu-west-1:592388890799:certificate/e73047c4-950f-4a05-8168-939bf53c366b;SecurityGroup=sg-6015cc06;SmoothStreaming=false;ViewerProtocolPolicy=allow-all;WorkOrder=6C040425`
