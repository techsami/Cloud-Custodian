# Cloudformation template for lambda


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for lambda
`BusinessUnit=Enterprise;CodeForLambda=import json; import boto3; import datetime; import collections; print "Hello World";CostCentre=TABB;Description=lambda function;Environment=Development;FunctionName=cus-qsr-function-dev;Handler=index.handler;Inline=True;KmsKeyArn=arn:aws:kms:eu-west-1:592388890799:key/09cbf86c-963d-4d9d-991a-875e482d9ef2;LambdaExecutionRole=arn:aws:iam::592388890799:role/LambdaEC2fullAccess;MajorFunction=Communications;MemorySize=128;Runtime=python3.6;S3Bucket=S3Key;SecurityGroup=sg-6015cc06;Service=Boomi;ServiceLevel=Gold;Subnet1=devtest-eu-west-1b-cdn;Subnet2=devtest-eu-west-1c-dmz;TimeOut=3;Variable1Value=env_var1;Variable2Value=env_var2;Variable3Value=env_var3;Variable4Value=env_var4;Variable5Value=env_var5;WorkOrder=6C040425`

##### Description for each Parameter 

*	<b> Inline </b>: Select false if you wish to upload code from S3 bucket.

* <b>	FunctionName </b> : Name should be like cus-qsr-function-dev.


* <b> LambdaExecutionRole </b> : IAM Role that lambda will use

* <b> MemorySize </b> : Size of the memory to execute the lambda code.

* <b>	Runtime </b> : User need to select code type whether python or node.js

* <b>	TimeOut </b> : Time for Function execution

* <b>	Handler </b> : Entry Function name in the Code File (Python :lambda_function.lambda_handler, Node..js :index.handler )

* <b>	Variable1Value </b> : Reference this value using the vaiable env_var1

* <b>	SecurityGroup </b> : Name of an existing Security Group for the lambda function

* <b>	Subnet1 </b> : Lambda First subnet

* <b>	Subnet2 </b> : Lambda Second subnet

* <b>	KmsKeyArn </b>: ARN of KMS Key to encrypt the Environment variables.

* <b>	S3Bucket </b> : Enter Bucket name where your code lies

* <b>	S3Key </b> : Enter Zip file name of your code

* <b>	CodeForLambda </b> : Enter your code if you have selected Inline as True and should contain 4096 characters only.

* <b>	Owner </b> : Owner detals (Mandatory)
* <b>	BusinessUnit </b> : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)


