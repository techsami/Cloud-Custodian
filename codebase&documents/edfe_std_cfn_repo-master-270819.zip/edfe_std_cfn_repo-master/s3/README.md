# Cloudformation template for S3


##### Parameter need to pass


You need to pass parameter in jenkins,please check the below mentioned sample



###### Example for S3
`AccessControl=Private;BucketName=edfe-ent-cfnstack-dev;KMSARN=arn:aws:kms:eu-west-1:592388890799:key/09cbf86c-963d-4d9d-991a-875e482d9ef2;BusinessUnit=Enterprise;MajorFunction=Communications;Service=LAN;CostCentre=TABB;Environment=Development;ServiceLevel=Gold;WorkOrder=6C040425`

###### Description for each Parameter :
* <b> BucketName </b> : Must be lowercase, dashes, no spaces. e.g. edfe-businessUnit-bucket-environmet[edfe-cus-testbucket-dev]
* <b> KMSARN </b> : ARN of KMS Key for server side encryption
* <b> AccessControl </b> : It will defined the access restriction on bucket
* <b> Owner </b> : Owner detals (Mandatory)
* <b> BusinessUnit </b> : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)
* <b> MajorFunction </b> : Sub Business Unit or core component group (Mandatory)
* <b> CostCentre </b> : Cost Centre e.g. CITR, OXTR, TAG (Mandatory)
* <b> Environment </b> : EDF Environments(SandPit\DEVTEST\Preproduction\Production)
* <b> ServiceLevel </b> : EDF service levels  i.e Platinum\Gold\Silver\Bronze
* <b> WorkOrder </b> : Work Order Reference Number
