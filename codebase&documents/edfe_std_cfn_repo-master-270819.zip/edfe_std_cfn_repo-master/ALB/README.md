
# Cloudformation template for ALB


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for ALB
`ALBName=testalb;ALBSecurityGroup=sg-e559879d;BusinessUnit=Enterprise;CertificateArn=arn:aws:acm:eu-west-1:592388890799:certificate/04b5ab7e-93b5-45ce-a4ab-327a5ea83ff8;CostCentre=TAFA;Environment=Development;Instance1=i-01e71ee370a80ecd9;Instance2=i-0302e7f1f427ba0db;MajorFunction=Communications;PublicSubnet1=devtest-eu-west-1c-dev;PublicSubnet2=devtest-eu-west-1b-cdn;Scheme=internal;Service=BOOMI;ServiceLevel=Gold;TargetName=testalb2;WorkOrder=1234`

##### Description for each Parameter 

* <b>	ALBName </b> : Enter the name of ALB.
* <b>	TargetName </b>
: Enter Target Name.
* <b>	Instance1 </b>
: Select first instance for ALB.
* <b>	Instance2 </b>
: Select second instance for ALB.
* <b> certificateArn </b>
: Enter the ARN of the certificate to associate with listener.
* <b>	InstanceSchedule </b>
: EC2 instance uptime (Mandatory). Please note, values other than 24x7 is
            applicable for Monday-Friday only
* <b>	Scheme </b>
: Define Type of ALB. Internet-facing will be accessible to internet user and Internal type will only be accessible to internal vpc network users.
* <b>	 PublicSubnet1 </b>
: Instance subnet (Mandatory)
* <b>	PublicSubnet2 </b>
: Instance subnet (Mandatory)
* <b>	PublicSubnet3 </b>
: Instance subnet (Mandatory)
* <b> ALBSecurityGroup </b>
: Select your security group.
* <b>	Owner </b>
: Owner detals (Mandatory)
* <b>	BusinessUnit </b>
: List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)
* <b>	MajorFunction </b>
: Sub Business Unit or core component group (Mandatory)
* <b>	CostCentre </b>
: Cost Centre e.g. CITR, OXTR, TAG (Mandatory)
* <b>	Environment </b>
: EDF Environments(SandPit\DEVTEST\Preproduction\Production)
* <b>	ServiceLevel </b>
: EDF service levels  i.e Platinum\Gold\Silver\Bronze
* <b>	WorkOrder </b>
: Work Order Reference Number
