
# Cloudformation template for Security Group


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for Security Group
`BusinessUnit=Enterprise;CidrIp1=10.0.0.0/8;CidrIp2=10.0.0.0/8;CidrIp3=10.0.0.0/8;CidrIp4=10.0.0.0/8;CidrIp5=10.0.0.0/8;CidrIp6=10.0.0.0/8;CostCentre=TAFA;Description1=test;Description2=test;Description3=test;Description4=test;Description5=test;Description6=test;Environment=Development;FromPort1=80;FromPort2=443;FromPort3=22;FromPort4=23;FromPort5=80;FromPort6=443;InboundCount=4;IpProtocol1=TCP;IpProtocol2=TCP;IpProtocol3=TCP;IpProtocol4=TCP;IpProtocol5=TCP;IpProtocol6=TCP;MajorFunction=Communications;OutboundCount=2;Service=LAN;ServiceLevel=Gold;SGDescription=SG-TESTDEVAWSTEST;SGName=SG-TESTDEVAWSTEST-002;ToPort1=80;ToPort2=443;ToPort3=22;ToPort4=23;ToPort5=80;ToPort6=443;VPC=vpc-a5573bc1;WorkOrder=6C040425;`


###### Description for each Parameter

* <b>	VPC </b> : This parameter will list the name of the vpc which will be fetch from the logged in account.

* <b>	IpProtocol1 </b> : User need to select protocol for first inbound rule.

* <b>	FromPort1 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort1 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	CidrIp1 </b> : Must be a valid CIDR range or IP of the form x.x.x.x/x

* <b>	IpProtocol2 </b> : User need to select protocol for second inbound rule.

* <b>	FromPort2 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort2 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	CidrIp2 </b> : Must be a valid CIDR range or IP of the form x.x.x.x/x


* <b>	IpProtocol3 </b> : User need to select protocol for third inbound rule.

* <b>	FromPort3 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort3 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	CidrIp3 </b> : Description: Must be a valid CIDR range or IP of the form x.x.x.x/x

* <b>	IpProtocol4 </b> : User need to select protocol for fourth inbound rule.

* <b>	FromPort4 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort4 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	CidrIp4 </b> : Must be a valid CIDR range or IP of the form x.x.x.x/x

* <b>	IpProtocol5 </b> : User need to select protocol for first outbound rule.

* <b>	FromPort5 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort5 </b> : User need to give port rang3e. Eg. 443 for HTTPS

* <b>	CidrIp5 </b> : Must be a valid CIDR range or IP of the form x.x.x.x/x

* <b>	IpProtocol6 </b> : User need to select protocol for second outbound rule.

* <b>	FromPort6 </b> : User need to give port range. Eg. 443 for HTTPS

* <b>	ToPort6 </b> : User need to give port rang3e. Eg. 443 for HTTPS

* <b> CidrIp6 </b> : Must be a valid CIDR range or IP of the form x.x.x.x/x

* <b>	SGName </b> : Name of the security group.

* <b>	SGDescription </b> : Basic detail about security group.

* <b>	Owner </b> : Owner detals (Mandatory)

* <b>	BusinessUnit </b> : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)

* <b>	MajorFunction </b> : Sub Business Unit or core component group (Mandatory)

* <b>	CostCentre </b> : Cost Centre e.g. CITR, OXTR, TAG (Mandatory)

* <b>	Environment </b> :EDF Environments(SandPit\DEVTEST\Preproduction\Production)

* <b>	ServiceLevel </b> : EDF service levels  i.e Platinum\Gold\Silver\Bronze

* <b>	WorkOrder </b> : Work Order Reference Number
