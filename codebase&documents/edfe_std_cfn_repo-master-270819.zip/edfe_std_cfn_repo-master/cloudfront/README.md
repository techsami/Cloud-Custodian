
# Cloudformation template for cloudfront


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for cloudfront








###### Description for each Parameter

* <b>	DomainName </b> : The name will be taken as domain name for origin.

* <b>	Id </b> : This value lets you distinguish multiple origins in the same distribution from one another.

* <b>	ViewerProtocolPolicy </b> : Allow CloudFront to allow viewers to access your web content using either HTTP or HTTPS.

* <b>	AllowedHTTPMethods </b> : Allow CloudFront to allow viewers to access your web content using either HTTP, HTTPS or both.

* <b>	OriginProtocolPolicy </b> : The user need to choose https-only if wanted to access through https protocol only otherwise http.

* <b>	PriceClass </b> : Price class defines the edge location from where the content will get distributed.

* <b>	SmoothStreaming </b> : Select true. If you want to use Smooth Streaming to stream a live event.

* <b>	RestrictionType </b> : The geo location can be whitelisted or blacklisted.

* <b>	AcmCertificateArn </b> : To make the connection secure the certificate is required. The ARN can be provided.

* <b>	Comments </b> : General comments

* <b>	Owner </b> : Owner detals (Mandatory)

* <b> BusinessUnit </b> : List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)

* <b>	MajorFunction </b> : Sub Business Unit or core component group (Mandatory)

* <b> CostCentre </b> : Cost Centre e.g. CITR, OXTR, TAG (Mandatory)

* <b>	Environment </b> :EDF Environments(SandPit\DEVTEST\Preproduction\Production)

* <b>	ServiceLevel </b> : EDF service levels  i.e Platinum\Gold\Silver\Bronze

* <b>	WorkOrder </b> : Work Order Reference Number
