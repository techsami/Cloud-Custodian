
# Cloudformation template for IAM


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for IAM
`Environment=Sandpit;Policies=arn:aws:iam::aws:policy/AdministratorAccess;Project=aws;RoleName=aws-sandpit-test-role;ServiceTo=EC2`

##### Description for each Parameter 

* <b> RoleName </b>
: Name for the Role.

* <b> ServiceTo </b>
: Mention AWS Service which will assume this role like EC2, Lambda.

* <b> Policies </b>
: Enter comma separated ARNs of Policies to be attached.

* <b>	Project </b> : Mention the project name which will use this role.

* <b>	Environment </b>
:EDF Environments(SandPit\DEVTEST\Preproduction\Production)
