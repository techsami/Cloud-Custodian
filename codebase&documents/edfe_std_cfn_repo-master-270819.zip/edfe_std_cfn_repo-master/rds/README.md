# Cloudformation template for rds


##### Parameter need to pass


You need to pass parameter in jenkin, below sample given


###### Example for rds
`AvailibilityZone=Private-eu-west-1b;BusinessUnit=Enterprise;CostCentre=TAGG;DBAllocatedStorage=50;DBBackupRetention=28;DBBackupWindow=02:00-02:30;DBInstanceClass=db.m3.medium;DBInstanceIdentifier=RDSZIdentifier;DBMaintenanceWindow=Sun:00:00-Sun:00:30;DBName=RDSZdb;DBPassword=Welcome123;DBSubnetGroupName=dev2-rds-subnet-group;Environment=Development;KMSKey=arn:aws:kms:eu-west-1:592388890799:key/09cbf86c-963d-4d9d-991a-875e482d9ef2;MajorFunction=Communications;RDSDBEngineVersion=5.7.19;SecurityGroup=sg-6015cc06;Service=Boomi;ServiceLevel=Gold;StorageType=standard;WorkOrder=6C040425`

###### Description for each Parameter :

* <b> DBInstanceIdentifier </b>
: The RDS Instance Identifier

* <b> AvailibilityZone </b>
: Availibility Zone of the instance (Mandatory)

* <b>	DBName </b>
: The database name

* <b> DBPassword </b>
: The database admin account password

* <b>	DBAllocatedStorage </b>
: The size of the database (Gb)

* <b>	DBInstanceClass </b>
: 'Note : Encryption is supported for instances above m3.medium'

* <b>	DBSubnetGroupName </b>
: 'DB Subnet Group Name'

* <b> Owner </b>
: Owner detals (Mandatory)

* <b>	BusinessUnit </b>
: List of EDF Business Units(Enterprise\Corporate\Customer\Generation\Nuclear)

* <b>	MajorFunction </b>
: Sub Business Unit or core component group (Mandatory)

* <b>	CostCentre </b>
: Cost Centre e.g. CITR, OXTR, TAG (Mandatory)

* <b>	Environment </b>
:EDF Environments(SandPit\DEVTEST\Preproduction\Production)

* <b>	ServiceLevel </b>
: EDF service levels  i.e Platinum\Gold\Silver\Bronze

* <b>	WorkOrder </b>
: Work Order Reference Number
