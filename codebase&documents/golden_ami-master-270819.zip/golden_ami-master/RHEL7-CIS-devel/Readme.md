Hardening Ansible file
