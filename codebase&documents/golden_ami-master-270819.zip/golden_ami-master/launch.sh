#!/bin/bash

#To refresh proxy details
source ~/.bashrc

if aws --version ; then
    echo "awscli already installed"
else
    pip install awscli --upgrade --user
fi

set -e
creator=$1
ami=$(grep artifact_id /tmp/manifest.json|cut -d'"' -f4|cut -d':' -f2)
aws ec2 copy-image --name AWS-DUB-EC2-RHEL-Test --source-image-id $ami --source-region eu-west-1 --kms-key-id alias/AWS_DUB_KMS_EntSec_RootAmi_PRd --encrypted |grep ImageId|cut -d'"' -f4|cut -d':' -f2 > amiId
EncryptedAMI=$(cat amiId)
echo "The Encrypted AMI provisioned is ${EncryptedAMI}"
region=$(grep region Packer/Template.json |cut -d'"' -f4|cut -d':' -f2)
inst_type=$(grep instance_type Packer/Template.json |cut -d'"' -f4|cut -d':' -f2)
subnet=$(grep subnet_id Packer/Template.json |cut -d'"' -f4|cut -d':' -f2)
sg=$(grep security_group_id Packer/Template.json |cut -d'"' -f4|cut -d':' -f2)

#aws configure set aws_access_key_id $aws_access_key
#aws configure set aws_secret_access_key $aws_secret_key
#aws configure set default.region $region

echo $creator >> output.txt
echo $EncryptedAMI >> output.txt
echo $EncryptedAMI > linuxgoldenami.txt
echo $region >> output.txt
echo inst_type >> output.txt
echo $subnet >> output.txt
echo $sg >> output.txt
sleep 5m
rm -rf /tmp/manifest.json
aws ec2 run-instances --region $region --image-id $EncryptedAMI \
                      --count 1 \
                      --instance-type $inst_type \
                      --subnet-id $subnet \
                      --key-name KEY_EntSec_Jenkins_PRD \
                      --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=AWS-Inspector-P001},{Key=Inspector,Value=Assessment},{Key=Business Unit,Value=Enterprise},{Key=Major Function,Value=DevOps},{Key=Environment,Value=Security},{Key=Service,Value=Jenkins},{Key=Service Level,Value=Bronze},{Key=Work Order,Value=6C040440},{Key=Cost Centre,Value=TABB},{Key=Creator,Value=$creator}]" > instance.json
cat instance.json

inst_id=$(grep InstanceId  instance.json |cut -d'"' -f4|cut -d':' -f2)

aws ec2  wait instance-status-ok --region eu-west-1 --instance-id $inst_id

rm -rf /tmp/manifest.json
