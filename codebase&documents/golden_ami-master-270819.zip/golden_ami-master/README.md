AMI Pipeline Project
