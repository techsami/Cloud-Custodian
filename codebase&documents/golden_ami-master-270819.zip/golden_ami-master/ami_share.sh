#!/bin/bash

#To Update proxy information
source ~/.bashrc

ami_id=$1
creator=$2
other_region=eu-west-2
today=`date +%d%m%Y`
name=AWS_LON_AMI_EntSec_Rhel_7.5_"$today"

if [[ -z $1 ]]
then
echo "Please enter AMI Id.."
exit 1
elif [[ $(aws ec2 describe-images --image-ids $ami_id --region eu-west-1 | grep State|cut -d'"' -f4) == 'available' ]]
then
accounts=`aws organizations list-accounts --query 'Accounts[].Id[]' --output=text --profile org`

for account in $accounts
do
  echo "Info::$account::Added"
  aws ec2 modify-image-attribute --image-id $ami_id --launch-permission "{\"Add\": [{\"UserId\":\"$account\"}]}" --region eu-west-1
  aws ec2 create-tags --resource $ami_id --region eu-west-1 --tags Key="Business Unit",Value="Enterprise" Key="Major Function",Value="DevOps" Key="Environment",Value="Production" Key="Service",Value="Jenkins" Key="Service Level",Value="Bronze" Key="Cost Centre",Value="TABB" Key="Work Order",Value="6C040440" Key=$creator,Value="AWS" Key="Name",Value="$name" 
done

#Copy Image to other region
lon_image=`aws ec2 copy-image --source-image-id $ami_id --source-region eu-west-1 --region $other_region --name "AWS_LON_AMI_EntSec_Rhel_7.5_$today"|grep "ImageId"|cut -d'"' -f4`
aws ec2 create-tags --resource $lon_image --region $other_region --tags Key="Business Unit",Value="Enterprise" Key="Major Function",Value="DevOps" Key="Environment",Value="Production" Key="Service",Value="Jenkins" Key="Service Level",Value="Bronze" Key="Cost Centre",Value="TABB" Key="Work Order",Value="6C040440" Key="Creator",Value=$creator Key="Name",Value="$name"
echo "Debug::London Region Image::$lon_image"
while [[ $(aws ec2 describe-images --image-ids $lon_image --region $other_region | grep State|cut -d'"' -f4) == 'pending' ]]
do
  if [[ $(aws ec2 describe-images --image-ids $lon_image --region $other_region | grep State|cut -d'"' -f4) == 'available' ]]
  then
    break
  else
    echo "Your AMI is Baking in $other_region.."
    sleep 60
  fi
done

if [[ $(aws ec2 describe-images --image-ids $lon_image --region $other_region | grep State|cut -d'"' -f4) == 'available' ]]
then
  for other_account in $accounts
  do
  echo "Info::$other_account::Added::Region::$other_region"
  aws ec2 modify-image-attribute --image-id $lon_image --launch-permission "{\"Add\": [{\"UserId\":\"$other_account\"}]}" --region $other_region
  aws ec2 create-tags --resource $lon_image --region $other_region --tags Key="Business Unit",Value="Enterprise" Key="Major Function",Value="DevOps" Key="Environment",Value="Production" Key="Service",Value="Jenkins" Key="Service Level",Value="Bronze" Key="Cost Centre",Value="TABB" Key="Work Order",Value="6C040440" Key="Creator",Value=$creator Key="Name",Value="$name" 
  done
else
  echo "Error::Check your Golden AMI in London region::$lon_image"
fi
else
echo "Please enter valid AMI Id."
exit 1
fi
