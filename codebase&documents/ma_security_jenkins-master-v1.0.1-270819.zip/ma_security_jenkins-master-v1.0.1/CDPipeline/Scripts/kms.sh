#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
# This script needs improvement. This code should be moved to pipiline code. Also the directory structure needs to be modified.
set -e
kms_stack_name=${1}
pKmsKeyAliasName=${2}
Region=${3}
creator_val=${4}
business_unit=${5}
major_function=${6}
service=${7}
work_order=${8}
cost_center=${9}
service_level=${10}
environment=${11}
profile=${12}
if [[ $environment == *"Dev"* ]]; then
  templatefile_path="file://./CDPipeline/templates/AWS_KMSv1.0.1_Dev.json"
else
  templatefile_path="file://./CDPipeline/templates/AWS_KMSv1.0.1_PrePRD.json"
fi
#templatefile_path="file://./CDPipeline/templates/AWS_KMSv1.0.1.json"
aws cloudformation create-stack  \
			   --stack-name $kms_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=pKmsKeyAliasName,ParameterValue="$pKmsKeyAliasName" \
	ParameterKey=Region,ParameterValue="$Region" \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile

aws cloudformation wait stack-create-complete --stack-name $kms_stack_name --profile $profile
