#!/bin/bash
new_account_profile=$1
aws s3 ls --profile $new_account_profile
if [ $? -eq 0 ]; then
        echo true > profileconf
else
        echo false > profileconf
fi
pwd
ls -la profileconf
