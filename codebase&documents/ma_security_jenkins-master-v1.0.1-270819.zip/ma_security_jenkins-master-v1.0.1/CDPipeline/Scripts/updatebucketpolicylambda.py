# -*- coding: utf-8 -*-
import boto3
import sys
import json
client = boto3.client('lambda')
account_var=sys.argv[1]
print(account_var)
query={"account": account_var}
query=json.dumps(query)
print(query)
response=client.invoke(
FunctionName='AWS_DUB_Lam_0055_PolicyUpdateLambda',
InvocationType='Event',
LogType='Tail',
Payload=query)
print(response)
