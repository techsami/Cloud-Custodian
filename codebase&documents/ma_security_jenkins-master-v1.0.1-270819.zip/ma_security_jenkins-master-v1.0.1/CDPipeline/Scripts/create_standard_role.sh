#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
# This script needs improvement. This code should be moved to pipiline code. Also the directory structure needs to be modified.
set -e
role_stack_name=${1}
region=${2}
environment_classification=${3}
creator_val=${4}
business_unit=${5}
major_function=${6}
service=${7}
work_order=${8}
cost_center=${9}
service_level=${10}
environment=${11}
profile=${12}
update_stack=${13}
aws s3 cp CDPipeline/templates/MultiAccount_IAM_Standard_Roles.yml s3://cf-templates-1lb9al2n89qj4-eu-west-1/MultiAccount_IAM_Standard_Roles.yml
sleep 10
templatefile_path="https://cf-templates-1lb9al2n89qj4-eu-west-1.s3.amazonaws.com/MultiAccount_IAM_Standard_Roles.yml"
if [ $update_stack == "True" ] 
then
	aws cloudformation update-stack  \
				   --stack-name $role_stack_name \
				   		   --template-url $templatefile_path \
						   --capabilities CAPABILITY_NAMED_IAM \
						   --parameters \
		ParameterKey=Region,ParameterValue="$region" \
		ParameterKey=Environment,ParameterValue="$environment_classification" \
		--tags Key="Business Unit",Value=$business_unit \
		   Key="Major Function",Value=$major_function \
		   Key=Service,Value=$service \
		   Key="Cost Centre",Value=$cost_center \
		   Key=Environment,Value=$environment \
		   Key="Service Level",Value=$service_level \
		   Key="Work Order",Value=$work_order \
		   Key=Creator,Value=$creator_val \
		--profile $profile
	aws cloudformation wait stack-update-complete --stack-name $role_stack_name --profile $profile
fi
if [ $update_stack == "False" ] 
then
	aws cloudformation create-stack  \
				   --stack-name $role_stack_name \
						   --template-url $templatefile_path \
						   --capabilities CAPABILITY_NAMED_IAM \
						   --parameters \
		ParameterKey=Region,ParameterValue="$region" \
		ParameterKey=Environment,ParameterValue="$environment_classification" \
		--tags Key="Business Unit",Value=$business_unit \
		   Key="Major Function",Value=$major_function \
		   Key=Service,Value=$service \
		   Key="Cost Centre",Value=$cost_center \
		   Key=Environment,Value=$environment \
		   Key="Service Level",Value=$service_level \
		   Key="Work Order",Value=$work_order \
		   Key=Creator,Value=$creator_val \
		--profile $profile
	aws cloudformation wait stack-create-complete --stack-name $role_stack_name --profile $profile
fi

