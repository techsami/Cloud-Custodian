#!/bin/bash -xe
#source ~/.bash_profile
#This script to assign Budget to a specific account
# This script needs improvement. This code should be moved to pipiline code. Also the directory structure needs to be modified.
set -e
budget_stack_name=${1}
BudgetLimit=${2}
EmailID=${3}
creator_val=${4}
business_unit=${5}
major_function=${6}
service=${7}
work_order=${8}
cost_center=${9}
service_level=${10}
environment=${11}
update_stack=${12}
profile=${13}
templatefile_path="file://./CDPipeline/templates/AWS-budget.yml"
if [ $update_stack == "False" ] 
then
aws cloudformation create-stack  \
			   --stack-name $budget_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=BudgetLimit,ParameterValue="$BudgetLimit" \
	ParameterKey=EmailID,ParameterValue="$EmailID" \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
aws cloudformation wait stack-create-complete --stack-name $budget_stack_name --profile $profile
fi
if [ $update_stack == "True" ] 
then
aws cloudformation update-stack  \
			   --stack-name $budget_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=BudgetLimit,ParameterValue="$BudgetLimit" \
	ParameterKey=EmailID,ParameterValue="$EmailID" \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
aws cloudformation wait stack-update-complete --stack-name $budget_stack_name --profile $profile
fi

sns_resource_name_arn=`aws cloudformation describe-stack-resources --stack-name $budget_stack_name --query StackResources[].PhysicalResourceId[] --output text --profile $profile|awk '{print $2}'`
aws sns tag-resource --resource-arn $sns_resource_name_arn --tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key="Service",Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key="Environment",Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key="Creator",Value=$creator_val \
	--profile $profile
