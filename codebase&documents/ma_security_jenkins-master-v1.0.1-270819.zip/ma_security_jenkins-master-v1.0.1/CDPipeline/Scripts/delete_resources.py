import boto3
import sys
import time

# sleeping for 300 seconds aka 5 minutes
time.sleep(300)

session = boto3.session.Session(profile_name=sys.argv[1])
client = session.client('ec2')
regions = client.describe_regions()

for regionName in regions['Regions']:
	region = regionName['RegionName']
	client = session.client('ec2',region_name=region)
	
	print '**************************\nRegion:', region
	
	response = client.describe_vpcs(
		Filters=[
			{
				'Name': 'isDefault',
				'Values': [
					'true'
				]
			}
		]
	)
	try:
		for vpcs in response['Vpcs']:
			VPCid = vpcs['VpcId']
		
			response = client.describe_subnets(Filters=[
		        {
		            'Name': 'vpc-id',
		            'Values': [
		                VPCid
		            ]
		        }
		    ])
		    
			try:
				for subnets in response['Subnets']:
					subnet = subnets['SubnetId']
					print 'Subnet Id:', subnet
					
					delSubnet = client.delete_subnet(
						SubnetId=str(subnet),
						DryRun=False
					)
					
					print 'Subnet deleted successfully'
			except:
				print 'No default Subnets found'
					
			response = client.describe_internet_gateways(Filters=[
		        {
		            'Name': 'attachment.vpc-id',
		            'Values': [
		            	VPCid
		            ]
		        }
		    ])
			try:
				try:
					igw = response['InternetGateways'][0]['InternetGatewayId']
					print '\nInternet Gateway Found. Id:',igw
				
					print 'trying detaching..'
					# vpc = response['InternetGateways'][0]['Attachments'][0]['VpcId']
					# removed as called above
					response = client.detach_internet_gateway(
						DryRun=False,
						InternetGatewayId=igw,
						VpcId=VPCid
					)
				
					print 'Successfully detached IGW from the VPC'
					
				except:
					print 'No attachment found with the default VPC'
					
				finally:
					delIGW = client.delete_internet_gateway(
						DryRun=False,
						InternetGatewayId=igw
					)
			
					print 'Successfully deleted IGW from',region
			except:
				print 'No default IGW found in: ',region
				
			# response = client.describe_vpcs(
			# 	Filters=[
			# 		{
			# 			'Name': 'isDefault',
			# 			'Values': [
			# 				'true'
			# 			]
			# 		}
			# 	]
			# )
			try:
				# VPC = response['Vpcs'][0]['VpcId']
				# print '\nDefault VPC Id:',VPCid
					
				response = client.delete_vpc(
					VpcId=str(VPCid),
					DryRun=False
				)
				print 'VPC deleted successfully'
			except:
				print '\nNo VPC found'
				
			response1 = client.describe_dhcp_options()
			try:
				dhcp = response1['DhcpOptions'][0]['DhcpOptionsId']
				print '\nDHCP Options Id:',dhcp
				
				response = client.delete_dhcp_options(
					DhcpOptionsId=str(dhcp),
					DryRun=False
				)
				
				print 'DHCP options deleted successfully'
			except:
				print '\nNo DHCP options found'
	except:
		print 'error!'			
						
print '**************************\n\nAll default resources deleted successfully\n\n**************************'
