#!bin/bash
# Ver: 1.0.0
# checking for input variables

if [[ $# -ne 2 ]]; then
echo "Usage: ./deleteResource.sh <profile> <child_region>"
echo "Profile Name: Name of the aws profile"
echo "Region Name: Name of the region to delete."
echo "e.g. ./deleteResource.sh  123456789_profile_name eu-west-1"
exit
fi


set -e
profile=$1
child_region=$2


echo "***********************************************************************************" | tee -a log.txt
echo "Info: Region: $child_region ." | tee -a log.txt

#truncating file
truncate -s 0 def.txt #emptying the def.txt

#fetching line number of to get profile region
line=`wc -l < /var/lib/jenkins/.aws/config`

#fetching profile region 
profile_region=`tail -1 /var/lib/jenkins/.aws/config`

#Replace the region in /var/lib/jenkins/.aws/config
sed -i ""$line"s/$profile_region/region \= $child_region/" /var/lib/jenkins/.aws/config   

#Delete igw from VPC.
aws ec2 describe-internet-gateways --profile $profile --region $child_region > def1.txt

#taking vpc and igw id in variable
vpc=`grep "VpcId" def1.txt|cut -d'"' -f4` # Finding VPC id's
internet_gateway_id=`grep "InternetGatewayId" def1.txt|cut -d'"' -f4`

echo -e "Debug: Searching for internetGateway..." | tee -a log.txt
if [[ -z "$internet_gateway_id" ]]; then
	echo -e "Info: No InternetGateway Found: \n" | tee -a log.txt
else
	echo "" | tee -a log.txt
	if [ -z "${vpc}" ]; then
		echo "Info: IGW $internet_gateway_id is not attached to any VPC" | tee -a log.txt
	else
		echo "Info: ***Detaching internet gateway from $vpc ***" | tee -a log.txt
		aws ec2 detach-internet-gateway --internet-gateway-id $internet_gateway_id --vpc-id $vpc --profile $profile

		if [ $? -eq 0 ]; then
			echo "Info: IGW $internet_gateway_id detached sucessfully." | tee -a log.txt
		else
			echo "Error: Failed to Detach IGW:$internet_gateway_id" | tee -a log.txt
		fi
	fi

	echo "Info: *** Attempting to delete internetgateway $internet_gateway_id . ***" | tee -a log.txt
	aws ec2 delete-internet-gateway --internet-gateway-id $internet_gateway_id --profile $profile

	if [ $? -eq 0 ]; then
		echo "Info: IGW $internet_gateway_id deleted sucessfully." | tee -a log.txt
	else
		echo "Error: Failed to delete Internet Gateway: $internet_gateway_id" | tee -a log.txt
	fi
fi


#delete subnet
aws ec2 describe-subnets --profile $profile > def.txt

#taking subnet id in variable
subnet=`grep "SubnetId" def.txt|cut -d'"' -f4`

echo -e "Debug: Deleting Subnets Operation... " | tee -a log.txt

for subnet in $subnet
	do
		echo "Debug: *** Deleting subnet: $subnet ***" | tee -a log.txt
		aws ec2 delete-subnet --subnet-id $subnet --profile $profile
			if [ $? -eq 0 ]; then
				echo "Info: Subnet ID $subnet deleted sucessfully." | tee -a log.txt
			else
				echo "Error: Failed to delete Subnet ID $subnet" | tee -a log.txt
			fi
	done


#delete VPC
echo "Debug: Deleting VPC operation:"
if [ -z "${vpc}" ]; then
	#echo "Info: no vpc found from internet gateway. Trying from describe-vpcs." | tee -a log.txt
	aws ec2 describe-vpcs --profile $profile > def.txt
	vpc=`grep "VpcId" def.txt|cut -d'"' -f4`
	echo "Debug: vpc found $vpc" | tee -a log.txt
else
	echo "Info: No VPC found" | tee -a log.txt
fi

if [ -z "${vpc}" ]; then
	echo "" | tee -a log.txt
else
    echo "Info:VPC Found $vpc" | tee -a log.txt

    aws ec2 delete-vpc --vpc-id $vpc --profile $profile | tee -a log.txt
	if [ $? -eq 0 ]; then
		echo "Info: VPC $vpc deleted sucessfully." | tee -a log.txt
	else
		echo "Error: Failed to delete VPC $vpc" | tee -a log.txt
	fi
fi


#delete dhcp options
aws ec2 describe-dhcp-options --profile $profile > def.txt
dhcp_opt=`grep "DhcpOptionsId" def.txt|cut -d'"' -f4`
echo "" | tee -a log.txt
echo -e "Debug: Deleting DHCP option Operation... " | tee -a log.txt

if [ -z "${dhcp_opt}" ]; then
	echo "Info: No DHCP Option found" | tee -a log.txt
else
	aws ec2 delete-dhcp-options --dhcp-options-id $dhcp_opt --profile $profile
		if [ $? -eq 0 ]; then
			echo "Info: dhcp  $dhcp_opt deleted sucessfully." | tee -a log.txt
		else
			echo "Error: Failed to delete dhcp  $dhcp_opt" | tee -a log.txt
		fi
fi

sed -i ""$line"s/region \= $child_region/region \= eu-west-1/" /var/lib/jenkins/.aws/config
