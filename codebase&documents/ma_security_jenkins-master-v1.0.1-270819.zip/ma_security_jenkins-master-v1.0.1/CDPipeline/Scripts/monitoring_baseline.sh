#!/bin/bash -xe
#source ~/.bash_profile
#Assigning variables that are coming from Pipeline starts here
# This script needs improvement. This code should be moved to pipiline code. Also the directory structure needs to be modified.
set -e
sleep 10
monitoring_stack_name=${1}
pAccountName=${2}
pCloudTrailBucketName=${3}
pCloudTrailKMSKeyId=${4}
pCloudTrailLogGroupName=${5}
pCloudTrailName=${6}
pKMSMasterKeyID=${7}
pNotifyEmail=${8}
pS3ServerAccessLogsBucketName=${9}
pSupportsGlacier=${10}

creator_val=${11}
business_unit=${12}
major_function=${13}
service=${14}
work_order=${15}
cost_center=${16}
service_level=${17}
environment=${18}
profile=${19}
templatefile_path="file://./CDPipeline/templates/cloudtrail.yaml"
aws cloudformation create-stack  \
			   --stack-name $monitoring_stack_name \
					   --template-body $templatefile_path \
					   --capabilities CAPABILITY_NAMED_IAM \
					   --parameters \
	ParameterKey=pAccountName,ParameterValue="$pAccountName" \
	ParameterKey=pCloudTrailBucketName,ParameterValue="$pCloudTrailBucketName" \
	ParameterKey=pCloudTrailKMSKeyId,ParameterValue="$pCloudTrailKMSKeyId" \
	ParameterKey=pCloudTrailLogGroupName,ParameterValue="$pCloudTrailLogGroupName" \
	ParameterKey=pCloudTrailName,ParameterValue="$pCloudTrailName" \
	ParameterKey=pKMSMasterKeyID,ParameterValue="$pKMSMasterKeyID" \
	ParameterKey=pNotifyEmail,ParameterValue="$pNotifyEmail" \
	ParameterKey=pS3ServerAccessLogsBucketName,ParameterValue="$pS3ServerAccessLogsBucketName" \
	ParameterKey=pSupportsGlacier,ParameterValue="$pSupportsGlacier" \
	--tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile

aws cloudformation wait stack-create-complete --stack-name $monitoring_stack_name --profile $profile
sns_resource_name_arn=$(aws cloudformation describe-stacks --stack-name $monitoring_stack_name --query Stacks[].Outputs[0].[OutputValue] --output text --profile $profile)
aws sns tag-resource --resource-arn $sns_resource_name_arn --tags Key="Business Unit",Value=$business_unit \
       Key="Major Function",Value=$major_function \
       Key=Service,Value=$service \
       Key="Cost Centre",Value=$cost_center \
       Key=Environment,Value=$environment \
       Key="Service Level",Value=$service_level \
       Key="Work Order",Value=$work_order \
       Key=Creator,Value=$creator_val \
	--profile $profile
