#todo
#update function to update the lambda environment variable
#account id 594028570116
# accName
# bucketName - regional specific
# kmskeyId - region specific
step 1.
aws lambda update-function-configuration --function-name testlambda23 --environment Variables="{accId='594028570116',accName='Audittrailaccount',bucketName='cfn-template-edfe',kmskeyId='arn:aws:kms:eu-west-1:279617892825:key/040e00e5-8ad6-484f-8e1b-c5e228eadd51'}" --profile sandpit_profile_name
step 2.
aws lambda invoke --function-name testlambda23 --profile sandpit_profile_name outputfile2.txt

step 3. 

