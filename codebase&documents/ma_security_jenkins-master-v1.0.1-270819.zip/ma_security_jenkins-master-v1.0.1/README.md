# Security Jenkins
Security jenkins has been configured for managing all security activities in EDFE multiaccount. Security jenkins performs following actions via jenkins pipeline as of now.

        . AWS Account Creation

# Contents
This repository contains following artifacts i.e cloud formation templates,shell scripts and jenkins file. Jenkins pipeline uses the artifacts for running builds.

       1. Jenkinsfile: Jenkins file contains multiple stages which creates aws accounts,VPCs.Following are the stages 
       through which new accounts is created.
       
              1.1. Pre-deployment-parameters: This sections declares the passing parameters.
                        
              1.2. Installation Validation & DB connectivity: This section checks parameters and db connectivity.
                        
              1.3. Account Creation: In this section new account is created using aws cli commands.
                        
              1.4. Download SourceCode: This downloads the artifacts that are required to performs below activity.
                        
              1.5. Default Resource Deletion: This section runs deleteResource.sh to delete default VPCs accross the                     region from newly created account
              
              1.6. VPC Creation: This section runs createVPC.sh to create VPC. createVPC.sh calls the VPC.yml cloud formation template which actually creates the VPC.
# Known Error
Default Resource Deletion Stage sometimes is not working
                        
[Page is under development]
